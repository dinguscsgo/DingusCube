package org.dingus.dingus;


import net.minecraft.entity.LivingEntity;

/**
 * Interface mixed into LivingEntityRenderState so we can
 * retrieve the source entity during rendering.
 */
public interface EntityRefAccessor {
    LivingEntity dingusmod$getEntity();
    void dingusmod$setEntity(LivingEntity entity);
}
