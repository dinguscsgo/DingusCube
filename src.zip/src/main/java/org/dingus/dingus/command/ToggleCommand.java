package org.dingus.dingus.command;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;
import org.dingus.dingus.Dingus;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class ToggleCommand {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(
                literal("dingus")
                        .executes(ctx -> {
                            Dingus.toggle = !Dingus.toggle;
                            ctx.getSource().sendFeedback(
                                    Text.literal("Dingus: " + (Dingus.toggle ? "ON" : "OFF"))
                            );
                            return 1;
                        })
        );
    }
}
