package org.dingus.dingus.client;

import net.fabricmc.api.ClientModInitializer;

public class DingusClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
