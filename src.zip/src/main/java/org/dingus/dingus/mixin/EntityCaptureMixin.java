package org.dingus.dingus.mixin;

import net.minecraft.client.model.Model;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.dingus.dingus.EntityRefAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public class EntityCaptureMixin<T extends LivingEntity,
        S extends LivingEntityRenderState,
        M extends Model<?>> {

    @Inject(
            method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
            at = @At("TAIL")
    )
    private void captureEntity(T entity, S state, float partialTick, CallbackInfo ci) {
        ((EntityRefAccessor) state).dingusmod$setEntity(entity);
    }
}
