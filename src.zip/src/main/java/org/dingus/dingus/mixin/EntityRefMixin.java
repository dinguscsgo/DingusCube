package org.dingus.dingus.mixin;


import net.minecraft.client.data.Model;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.dingus.dingus.EntityRefAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Stores the source entity into the render state so PlayerRenderMixin can read it.
 */
@Mixin(LivingEntityRenderState.class)  // ← mixin into the STATE, not the renderer
public class EntityRefMixin implements EntityRefAccessor {

    @Unique
    private LivingEntity dingusmod$entityRef;

    @Override
    public LivingEntity dingusmod$getEntity() { return dingusmod$entityRef; }

    @Override
    public void dingusmod$setEntity(LivingEntity e) { dingusmod$entityRef = e; }
}