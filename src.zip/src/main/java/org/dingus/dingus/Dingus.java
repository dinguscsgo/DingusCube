package org.dingus.dingus;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.util.Identifier;
import org.dingus.dingus.command.ToggleCommand;

public class Dingus implements ModInitializer {
    // Slime texture override — see SlimeMixin below
    public static boolean toggle = true;
    public static final String MOD_ID = "dingus";

    public static final Identifier CUSTOM_SLIME_TEXTURE = Identifier.of(MOD_ID, "textures/entity/slime/slimefuckasstexture.png");

    @Override
    public void onInitialize() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                ToggleCommand.register(dispatcher)
        );
    }
}
