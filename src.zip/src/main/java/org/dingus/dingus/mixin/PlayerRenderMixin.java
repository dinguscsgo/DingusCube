package org.dingus.dingus.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.entity.state.SlimeEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.EntityType;
import org.dingus.dingus.Dingus;
import org.dingus.dingus.EntityRefAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.model.Model;

@Mixin(LivingEntityRenderer.class)
public abstract class PlayerRenderMixin<T extends LivingEntity,
        S extends LivingEntityRenderState,
        M extends Model<?>> {


    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onRender(S state, MatrixStack matrixStack, OrderedRenderCommandQueue queue, CameraRenderState cameraRenderState, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (!(state instanceof PlayerEntityRenderState playerState) || !Dingus.toggle) return;

        LivingEntity entity = ((EntityRefAccessor) state).dingusmod$getEntity();
        if (entity == null || !(entity instanceof PlayerEntity player)) return;

        if (player.isInvisibleTo(client.player)) return;

        SlimeEntity slime = new SlimeEntity(EntityType.SLIME, player.getEntityWorld());
        slime.age = 1;
        slime.setSize(2, false);

        slime.setPos(player.getX(), player.getY(), player.getZ());
        slime.lastX = player.lastX;
        slime.lastY = player.lastY;
        slime.lastZ = player.lastZ;

        slime.setYaw(player.getHeadYaw());
        slime.lastYaw = player.lastYaw;
        slime.setPitch(player.getPitch());
        slime.lastPitch = player.lastPitch;

        slime.bodyYaw = player.bodyYaw;
        slime.lastBodyYaw = player.lastBodyYaw;
        slime.headYaw = player.headYaw;
        slime.lastHeadYaw = player.lastHeadYaw;

        EntityRenderManager dispatcher = client.getEntityRenderDispatcher();
        float partialTick = client.getRenderTickCounter().getTickProgress(true);

        @SuppressWarnings("unchecked")
        EntityRenderer<SlimeEntity, SlimeEntityRenderState> slimeRenderer =
                (EntityRenderer<SlimeEntity, SlimeEntityRenderState>) dispatcher.getRenderer(slime);

        SlimeEntityRenderState slimeState = new SlimeEntityRenderState();
        slimeRenderer.updateRenderState(slime, slimeState, partialTick);

// Override AFTER updateRenderState so it doesn't clobber these
        slimeState.bodyYaw = playerState.bodyYaw;
        slimeState.relativeHeadYaw = playerState.relativeHeadYaw;
        slimeState.pitch = playerState.pitch;
        slimeState.limbSwingAnimationProgress = playerState.limbSwingAnimationProgress;
        slimeState.limbSwingAmplitude = playerState.limbSwingAmplitude;
        slimeState.baseScale = 1.0f;
        slimeState.age = playerState.age;
        slimeState.invisible = false;
        slimeState.invisibleToPlayer = false;
        slimeState.light = playerState.light;
        slimeState.x = playerState.x;
        slimeState.y = playerState.y;
        slimeState.z = playerState.z;
        slimeState.size = 2;
        slimeState.stretch = 0f;

// Flag for texture mixin

        slimeRenderer.render(slimeState, matrixStack, queue, cameraRenderState);


        // Render nametag using the shadowed protected method directly on this renderer
//        renderLabelIfPresent(state, player.getDisplayName(), matrixStack, queue, cameraRenderState);

        ci.cancel();
    }
}