package org.dingus.dingus.mixin;

import net.minecraft.client.render.entity.SlimeEntityRenderer;
import net.minecraft.client.render.entity.state.SlimeEntityRenderState;
import net.minecraft.util.Identifier;
import org.dingus.dingus.Dingus;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(net.minecraft.client.render.entity.SlimeEntityRenderer.class)
public class SlimeTextureMixin {
    @Shadow
    @Final
    @Mutable
    public static Identifier TEXTURE;

    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void modifyTexture(CallbackInfo ci) {
        TEXTURE = Dingus.CUSTOM_SLIME_TEXTURE;
    }
}